-- Lab Sheet 4: SQL Operators (MySQL)
USE CollegeDB;

CREATE TABLE IF NOT EXISTS Student (
    Student_ID INT PRIMARY KEY,
    Name VARCHAR(50),
    Age INT,
    Course VARCHAR(50),
    City VARCHAR(50),
    Department_ID INT NULL
);
CREATE TABLE IF NOT EXISTS Employee (
    Emp_ID INT PRIMARY KEY,
    Emp_Name VARCHAR(50),
    Department VARCHAR(50),
    Salary DECIMAL(10,2)
);
CREATE TABLE IF NOT EXISTS Product (
    Product_ID INT PRIMARY KEY,
    Product_Name VARCHAR(100),
    Price DECIMAL(10,2),
    Quantity INT
);

INSERT IGNORE INTO Student VALUES
(1, 'Aman Sharma', 20, 'BCA', 'Delhi', 10),
(2, 'Asha Verma', 19, 'BSc', 'Meerut', 20),
(3, 'Ravi Kumar', 22, 'BCA', 'Noida', NULL);
INSERT IGNORE INTO Employee VALUES
(101, 'Mohit', 'IT', 35000),
(102, 'Simran', 'HR', 42000),
(103, 'Arjun', 'IT', 28000);
INSERT IGNORE INTO Product VALUES
(201, 'Keyboard', 800, 5),
(202, 'Mouse', 450, 0);

-- Arithmetic operators
-- 1-4. Addition, subtraction, multiplication, division
SELECT 10 + 5 AS Addition, 10 - 5 AS Subtraction,
       10 * 5 AS Multiplication, 10 / 5 AS Division;
-- 5. Price multiplied by quantity
SELECT Product_Name, Price, Quantity, Price * Quantity AS Total_Amount
FROM Product;

-- Logical operators
-- 6. AND
SELECT * FROM Student WHERE Course = 'BCA' AND Age > 18;
-- 7. OR
SELECT * FROM Student WHERE City = 'Delhi' OR City = 'Meerut';
-- 8. NOT
SELECT * FROM Student WHERE NOT City = 'Delhi';
-- 9. Specific course AND city
SELECT * FROM Student WHERE Course = 'BCA' AND City = 'Delhi';
-- 10. Either of two departments
SELECT * FROM Employee WHERE Department = 'IT' OR Department = 'HR';

-- Comparison operators
-- 11. =
SELECT * FROM Student WHERE City = 'Delhi';
-- 12. >
SELECT * FROM Student WHERE Age > 20;
-- 13. <
SELECT * FROM Student WHERE Age < 21;
-- 14. >= and <=
SELECT * FROM Student WHERE Age >= 19 AND Age <= 22;
-- 15. <> / !=
SELECT * FROM Student WHERE City <> 'Delhi';
SELECT * FROM Student WHERE City != 'Delhi';

-- Special operators
-- 16. BETWEEN
SELECT * FROM Employee WHERE Salary BETWEEN 30000 AND 45000;
-- 17. IN
SELECT * FROM Student WHERE City IN ('Delhi', 'Noida');
-- 18. NOT IN
SELECT * FROM Student WHERE City NOT IN ('Delhi', 'Noida');
-- 19. LIKE: names starting with A
SELECT * FROM Student WHERE Name LIKE 'A%';
-- 20. IS NULL and IS NOT NULL
SELECT * FROM Student WHERE Department_ID IS NULL;
SELECT * FROM Student WHERE Department_ID IS NOT NULL;

-- Set operations
-- 21. UNION removes duplicates
SELECT City AS Place FROM Student
UNION
SELECT Department AS Place FROM Employee;
-- 22. UNION ALL keeps duplicates
SELECT City AS Place FROM Student
UNION ALL
SELECT Department AS Place FROM Employee;
-- 23. MySQL does not support INTERSECT in older versions; use this workaround
SELECT DISTINCT s.City
FROM Student s
INNER JOIN (SELECT Department FROM Employee) e ON s.City = e.Department;
-- 24. MySQL does not support EXCEPT in older versions; use LEFT JOIN workaround
SELECT DISTINCT s.City
FROM Student s
LEFT JOIN Employee e ON s.City = e.Department
WHERE e.Department IS NULL;
-- 25. Combined arithmetic + logical + comparison + special operators
SELECT Product_Name, Price, Quantity, Price * Quantity AS Total_Amount
FROM Product
WHERE Price > 400 AND Quantity BETWEEN 1 AND 10
  AND Product_Name LIKE '%e%';
