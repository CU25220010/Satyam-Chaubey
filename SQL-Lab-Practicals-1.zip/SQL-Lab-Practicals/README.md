# SQL Lab Practicals (Lab Sheets 1–5)

This repository contains MySQL examples for the five DBMS lab sheets.

## Files
- `Lab1_DDL.sql` — CREATE, ALTER, DROP and constraints
- `Lab2_DML.sql` — INSERT, UPDATE and DELETE
- `Lab3_Functions.sql` — number, aggregate, character, conversion and date functions
- `Lab4_Operators.sql` — arithmetic, logical, comparison, special and set-operation examples
- `Lab5_Joins.sql` — INNER, LEFT, RIGHT, CROSS, NATURAL and SELF JOIN examples
- `Lab Sheet 1-5.pdf` — original assignment sheet (upload this PDF separately if it is not included)

## How to run
1. Open MySQL Workbench and connect to your local MySQL server.
2. Open one `.sql` file.
3. Execute the script (lightning bolt icon).
4. Read the comments before running destructive statements.

## Notes
- The examples use MySQL syntax.
- Run the lab files one at a time. Some sheets create sample tables with the same names.
- `TRUNCATE`, `DROP`, and `DELETE` statements that could remove data are commented out where appropriate.
- MySQL `CHECK` constraints are enforced in MySQL 8.0.16 and newer.
- MySQL does not support `FULL OUTER JOIN` directly; Lab 5 demonstrates a `LEFT JOIN` + `RIGHT JOIN` `UNION` workaround.
