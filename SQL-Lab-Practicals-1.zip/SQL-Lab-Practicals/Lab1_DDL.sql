-- Lab Sheet 1: DDL Commands - CREATE, ALTER, DROP
-- DBMS: MySQL
CREATE DATABASE IF NOT EXISTS CollegeDB;
USE CollegeDB;

-- 1-2. Create database and Student table
CREATE TABLE IF NOT EXISTS Student (
    Student_ID INT,
    Name VARCHAR(50),
    Age INT,
    Course VARCHAR(50),
    City VARCHAR(50)
);

-- 3. Employee table
CREATE TABLE IF NOT EXISTS Employee (
    Emp_ID INT,
    Emp_Name VARCHAR(50),
    Department VARCHAR(50),
    Salary DECIMAL(10,2)
);

-- 4. Department table
CREATE TABLE IF NOT EXISTS Department (
    Dept_ID INT,
    Dept_Name VARCHAR(50),
    Location VARCHAR(50)
);

-- 5. Product table
CREATE TABLE IF NOT EXISTS Product (
    Product_ID INT,
    Product_Name VARCHAR(100),
    Price DECIMAL(10,2),
    Quantity INT
);

-- 6. Customer table
CREATE TABLE IF NOT EXISTS Customer (
    Customer_ID INT,
    Customer_Name VARCHAR(100),
    Email VARCHAR(100),
    Phone VARCHAR(20)
);

-- 7. Course table
CREATE TABLE IF NOT EXISTS Course (
    Course_ID INT,
    Course_Name VARCHAR(100),
    Duration VARCHAR(50),
    Fees DECIMAL(10,2)
);

-- 8. Faculty table
CREATE TABLE IF NOT EXISTS Faculty (
    Faculty_ID INT,
    Faculty_Name VARCHAR(100),
    Subject VARCHAR(100),
    Salary DECIMAL(10,2)
);

-- 9. Library table
CREATE TABLE IF NOT EXISTS Library (
    Book_ID INT,
    Book_Name VARCHAR(150),
    Author VARCHAR(100),
    Price DECIMAL(10,2)
);

-- 10. Department with Primary Key (separate example table)
CREATE TABLE IF NOT EXISTS Department_PK (
    Dept_ID INT PRIMARY KEY,
    Dept_Name VARCHAR(50),
    Location VARCHAR(50)
);

-- 11. Student with Primary Key and NOT NULL
CREATE TABLE IF NOT EXISTS Student_Constraints (
    Student_ID INT PRIMARY KEY,
    Name VARCHAR(50) NOT NULL,
    Age INT,
    Course VARCHAR(50),
    City VARCHAR(50)
);

-- 12. Employee with UNIQUE Email
CREATE TABLE IF NOT EXISTS Employee_Unique (
    Emp_ID INT PRIMARY KEY,
    Emp_Name VARCHAR(50),
    Email VARCHAR(100) UNIQUE,
    Department VARCHAR(50),
    Salary DECIMAL(10,2)
);

-- 13. Product with CHECK constraint (MySQL 8.0.16+ enforces CHECK)
CREATE TABLE IF NOT EXISTS Product_Check (
    Product_ID INT PRIMARY KEY,
    Product_Name VARCHAR(100),
    Price DECIMAL(10,2) CHECK (Price > 0),
    Quantity INT
);

-- 14-15. Add Email and Phone columns to Student
ALTER TABLE Student ADD COLUMN Email VARCHAR(100);
ALTER TABLE Student ADD COLUMN Phone VARCHAR(20);

-- 16. Modify Name column size/type
ALTER TABLE Student MODIFY COLUMN Name VARCHAR(100);

-- 17. Rename Student table
ALTER TABLE Student RENAME TO Student_Details;

-- 18. Rename City column to Address
ALTER TABLE Student_Details RENAME COLUMN City TO Address;

-- 19. Add Salary to Employee
ALTER TABLE Employee ADD COLUMN Salary_Updated DECIMAL(10,2);

-- 20-21. Drop Phone and Email from Student_Details
ALTER TABLE Student_Details DROP COLUMN Phone;
ALTER TABLE Student_Details DROP COLUMN Email;

-- 22. TRUNCATE removes all rows but keeps the table structure.
-- Run only when you are ready to delete all records:
-- TRUNCATE TABLE Student_Details;

-- 23-24. DROP tables (commented out to avoid accidental data loss)
-- DROP TABLE Course;
-- DROP TABLE Customer;

-- 25. Complete Student table using PK, NOT NULL, UNIQUE and CHECK
CREATE TABLE IF NOT EXISTS Student_Complete (
    Student_ID INT PRIMARY KEY,
    Name VARCHAR(50) NOT NULL,
    Email VARCHAR(100) UNIQUE,
    Age INT CHECK (Age >= 16),
    Course VARCHAR(50),
    City VARCHAR(50)
);

-- Suitable DROP examples (uncomment only if required)
-- ALTER TABLE Student_Complete DROP COLUMN City;
-- DROP TABLE Student_Complete;
