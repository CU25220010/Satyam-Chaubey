-- Lab Sheet 5: SQL Joins (MySQL)
USE CollegeDB;

-- Use consistent sample tables for the join exercises
CREATE TABLE IF NOT EXISTS Department (
    Dept_ID INT PRIMARY KEY,
    Dept_Name VARCHAR(50),
    Location VARCHAR(50)
);
CREATE TABLE IF NOT EXISTS Course (
    Course_ID INT PRIMARY KEY,
    Course_Name VARCHAR(50),
    Dept_ID INT
);
CREATE TABLE IF NOT EXISTS Student (
    Student_ID INT PRIMARY KEY,
    Name VARCHAR(50),
    Age INT,
    Course_ID INT NULL,
    Dept_ID INT NULL
);
CREATE TABLE IF NOT EXISTS Employee (
    Emp_ID INT PRIMARY KEY,
    Emp_Name VARCHAR(50),
    Department_ID INT NULL,
    Manager_ID INT NULL,
    Salary DECIMAL(10,2)
);

INSERT IGNORE INTO Department VALUES
(10, 'IT', 'Delhi'), (20, 'Science', 'Meerut'), (30, 'Commerce', 'Noida');
INSERT IGNORE INTO Course VALUES
(101, 'BCA', 10), (102, 'BSc', 20), (103, 'BCom', 30);
INSERT IGNORE INTO Student VALUES
(1, 'Rahul Sharma', 20, 101, 10),
(2, 'Priya Singh', 19, 102, 20),
(3, 'Amit Kumar', 21, 101, 10),
(4, 'Neha Verma', 20, NULL, NULL);
INSERT IGNORE INTO Employee VALUES
(201, 'Mohit', 10, NULL, 60000),
(202, 'Simran', 10, 201, 40000),
(203, 'Arjun', 20, 201, 45000);

-- 1-2. INNER JOIN Student and Department
SELECT s.Student_ID, s.Name, d.Dept_Name
FROM Student s
INNER JOIN Department d ON s.Dept_ID = d.Dept_ID;

-- 3. Employees with department names
SELECT e.Emp_Name, d.Dept_Name
FROM Employee e
INNER JOIN Department d ON e.Department_ID = d.Dept_ID;

-- 4. Students with course details
SELECT s.Name, c.Course_Name
FROM Student s
INNER JOIN Course c ON s.Course_ID = c.Course_ID;

-- 5. Students in a particular department
SELECT s.Name, d.Dept_Name
FROM Student s
INNER JOIN Department d ON s.Dept_ID = d.Dept_ID
WHERE d.Dept_Name = 'IT';

-- 6-7. LEFT JOIN: all students, including those without a department
SELECT s.Name, d.Dept_Name
FROM Student s
LEFT JOIN Department d ON s.Dept_ID = d.Dept_ID;

-- 8-9. RIGHT JOIN: all departments, including those without students
SELECT s.Name, d.Dept_Name
FROM Student s
RIGHT JOIN Department d ON s.Dept_ID = d.Dept_ID;

-- 10. Students not assigned to a department
SELECT s.*
FROM Student s
LEFT JOIN Department d ON s.Dept_ID = d.Dept_ID
WHERE d.Dept_ID IS NULL;

-- 11. Departments having no students
SELECT d.*
FROM Department d
LEFT JOIN Student s ON s.Dept_ID = d.Dept_ID
WHERE s.Student_ID IS NULL;

-- 12. FULL OUTER JOIN workaround for MySQL using LEFT JOIN + unmatched RIGHT-side rows
SELECT s.Student_ID, s.Name, d.Dept_Name
FROM Student s
LEFT JOIN Department d ON s.Dept_ID = d.Dept_ID
UNION
SELECT s.Student_ID, s.Name, d.Dept_Name
FROM Student s
RIGHT JOIN Department d ON s.Dept_ID = d.Dept_ID;

-- 13-14. CROSS JOIN and number of possible combinations
SELECT s.Name, c.Course_Name
FROM Student s
CROSS JOIN Course c;
SELECT (SELECT COUNT(*) FROM Student) * (SELECT COUNT(*) FROM Course)
AS Possible_Student_Course_Combinations;

-- 15. NATURAL JOIN (matching column names must be intentional)
-- These tables both contain Dept_ID, so MySQL joins using that shared column.
SELECT Student_ID, Name, Dept_Name
FROM Student NATURAL JOIN Department;

-- 16. Compare NATURAL JOIN with explicit INNER JOIN
SELECT s.Student_ID, s.Name, d.Dept_Name
FROM Student s INNER JOIN Department d ON s.Dept_ID = d.Dept_ID;

-- 17-18. SELF JOIN to show employee-manager relationships
SELECT e.Emp_Name AS Employee, m.Emp_Name AS Manager
FROM Employee e
LEFT JOIN Employee m ON e.Manager_ID = m.Emp_ID;

-- 19-20. Join Student, Department and Course
SELECT s.Name AS Student_Name, c.Course_Name, d.Dept_Name
FROM Student s
LEFT JOIN Course c ON s.Course_ID = c.Course_ID
LEFT JOIN Department d ON s.Dept_ID = d.Dept_ID;

-- 21. Employees earning more than their department's average salary
SELECT e.Emp_Name, e.Salary, d.Dept_Name
FROM Employee e
JOIN Department d ON e.Department_ID = d.Dept_ID
WHERE e.Salary > (
    SELECT AVG(e2.Salary)
    FROM Employee e2
    WHERE e2.Department_ID = e.Department_ID
);

-- 22. Department with the maximum number of students
SELECT d.Dept_ID, d.Dept_Name, COUNT(s.Student_ID) AS Student_Count
FROM Department d
LEFT JOIN Student s ON s.Dept_ID = d.Dept_ID
GROUP BY d.Dept_ID, d.Dept_Name
HAVING COUNT(s.Student_ID) = (
    SELECT MAX(Student_Count)
    FROM (
        SELECT COUNT(s2.Student_ID) AS Student_Count
        FROM Department d2
        LEFT JOIN Student s2 ON s2.Dept_ID = d2.Dept_ID
        GROUP BY d2.Dept_ID
    ) AS DepartmentCounts
);

-- 23. Departments and total number of students in each
SELECT d.Dept_Name, COUNT(s.Student_ID) AS Total_Students
FROM Department d
LEFT JOIN Student s ON s.Dept_ID = d.Dept_ID
GROUP BY d.Dept_ID, d.Dept_Name;

-- 24. Courses and number of students enrolled in each
SELECT c.Course_Name, COUNT(s.Student_ID) AS Enrolled_Students
FROM Course c
LEFT JOIN Student s ON s.Course_ID = c.Course_ID
GROUP BY c.Course_ID, c.Course_Name;

-- 25. Report using INNER JOIN, LEFT JOIN, GROUP BY and aggregate functions
SELECT d.Dept_Name, c.Course_Name,
       COUNT(s.Student_ID) AS Total_Students,
       AVG(s.Age) AS Average_Age
FROM Department d
INNER JOIN Course c ON c.Dept_ID = d.Dept_ID
LEFT JOIN Student s ON s.Course_ID = c.Course_ID
GROUP BY d.Dept_ID, d.Dept_Name, c.Course_ID, c.Course_Name
ORDER BY d.Dept_Name, c.Course_Name;
