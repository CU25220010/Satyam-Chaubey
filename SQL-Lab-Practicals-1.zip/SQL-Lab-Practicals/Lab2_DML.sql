-- Lab Sheet 2: DML Commands - INSERT, UPDATE, DELETE
USE CollegeDB;

-- Ensure a table is available for this lab
CREATE TABLE IF NOT EXISTS Student (
    Student_ID INT PRIMARY KEY,
    Name VARCHAR(50) NOT NULL,
    Age INT,
    Course VARCHAR(50),
    City VARCHAR(50)
);

CREATE TABLE IF NOT EXISTS Employee (
    Emp_ID INT PRIMARY KEY,
    Emp_Name VARCHAR(50),
    Department VARCHAR(50),
    Salary DECIMAL(10,2),
    Email VARCHAR(100)
);

CREATE TABLE IF NOT EXISTS Department (
    Dept_ID INT PRIMARY KEY,
    Dept_Name VARCHAR(50),
    Location VARCHAR(50)
);

CREATE TABLE IF NOT EXISTS Product (
    Product_ID INT PRIMARY KEY,
    Product_Name VARCHAR(100),
    Price DECIMAL(10,2),
    Quantity INT
);

CREATE TABLE IF NOT EXISTS Customer (
    Customer_ID INT PRIMARY KEY,
    Customer_Name VARCHAR(100),
    Email VARCHAR(100),
    Phone VARCHAR(20)
);

CREATE TABLE IF NOT EXISTS Course (
    Course_ID INT PRIMARY KEY,
    Course_Name VARCHAR(100),
    Duration VARCHAR(50),
    Fees DECIMAL(10,2)
);

-- 1. Insert one student
INSERT INTO Student (Student_ID, Name, Age, Course, City)
VALUES (1, 'Rahul Sharma', 20, 'BCA', 'Delhi');

-- 2. Five separate INSERT statements
INSERT INTO Student VALUES (2, 'Priya Singh', 19, 'BCA', 'Meerut');
INSERT INTO Student VALUES (3, 'Amit Kumar', 21, 'BSc', 'Delhi');
INSERT INTO Student VALUES (4, 'Neha Verma', 20, 'BCOM', 'Noida');
INSERT INTO Student VALUES (5, 'Rohit Gupta', 22, 'BTech', 'Ghaziabad');
INSERT INTO Student VALUES (6, 'Sana Khan', 19, 'BCA', 'Meerut');

-- 3. Multiple records in one statement
INSERT INTO Student (Student_ID, Name, Age, Course, City) VALUES
(7, 'Karan Mehta', 20, 'BCA', 'Delhi'),
(8, 'Anjali Jain', 21, 'BSc', 'Noida');

-- 4-8. Insert records into other tables
INSERT INTO Employee (Emp_ID, Emp_Name, Department, Salary, Email)
VALUES (101, 'Mohit Verma', 'IT', 35000, 'mohit@example.com');
INSERT INTO Department VALUES (10, 'IT', 'Delhi');
INSERT INTO Product VALUES (201, 'Keyboard', 799.00, 25);
INSERT INTO Customer VALUES (301, 'Aarav Singh', 'aarav@example.com', '9876543210');
INSERT INTO Course VALUES (401, 'BCA', '3 Years', 45000.00);

-- 9. All columns specified
INSERT INTO Student (Student_ID, Name, Age, Course, City)
VALUES (9, 'Isha Patel', 20, 'BCA', 'Meerut');

-- 10. Selected columns only
INSERT INTO Student (Student_ID, Name, Course)
VALUES (10, 'Dev Arora', 'BTech');

-- 11. Update city of a particular student
UPDATE Student SET City = 'Noida' WHERE Student_ID = 2;

-- 12. Update salary of one employee
UPDATE Employee SET Salary = 38000 WHERE Emp_ID = 101;

-- 13. Increase salary of all employees by 10%
UPDATE Employee SET Salary = Salary * 1.10;

-- 14. Increase all product prices by 5%
UPDATE Product SET Price = Price * 1.05;

-- 15. Change course of a particular student
UPDATE Student SET Course = 'BSc' WHERE Student_ID = 3;

-- 16. Update department of an employee
UPDATE Employee SET Department = 'Finance' WHERE Emp_ID = 101;

-- 17. Change Meerut students' city to Delhi
UPDATE Student SET City = 'Delhi' WHERE City = 'Meerut';

-- 18. Update fees of a course
UPDATE Course SET Fees = 48000 WHERE Course_ID = 401;

-- 19. Update multiple columns together
UPDATE Student SET Age = 21, City = 'Delhi' WHERE Student_ID = 4;

-- 20. Delete a particular student (example)
DELETE FROM Student WHERE Student_ID = 10;

-- 21. Delete students from a particular city (example)
-- DELETE FROM Student WHERE City = 'Noida';

-- 22. Delete employees below a salary threshold (example)
-- DELETE FROM Employee WHERE Salary < 25000;

-- 23. Delete products with zero quantity
-- DELETE FROM Product WHERE Quantity = 0;

-- 24. Multiple conditions using AND / OR (example)
-- DELETE FROM Student WHERE City = 'Delhi' AND Age < 18;
-- DELETE FROM Student WHERE City = 'Noida' OR City = 'Ghaziabad';

-- 25. Display table after operations
SELECT * FROM Student;
SELECT * FROM Employee;
SELECT * FROM Product;
