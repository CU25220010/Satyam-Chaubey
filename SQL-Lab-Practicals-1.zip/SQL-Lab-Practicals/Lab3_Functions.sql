-- Lab Sheet 3: SQL Functions (MySQL)
USE CollegeDB;

-- Sample tables and data for running the examples
CREATE TABLE IF NOT EXISTS Student (
    Student_ID INT PRIMARY KEY,
    Name VARCHAR(50),
    Age INT,
    Course VARCHAR(50),
    City VARCHAR(50)
);
CREATE TABLE IF NOT EXISTS Employee (
    Emp_ID INT PRIMARY KEY,
    Emp_Name VARCHAR(50),
    Department VARCHAR(50),
    Salary DECIMAL(10,2),
    Joining_Date DATE
);

INSERT IGNORE INTO Student VALUES
(1, 'Rahul Sharma', 20, 'BCA', 'Delhi'),
(2, 'Priya Singh', 19, 'BCA', 'Meerut'),
(3, 'Amit Kumar', 21, 'BSc', 'Noida');

INSERT IGNORE INTO Employee VALUES
(101, 'Mohit Verma', 'IT', 35500.75, '2023-06-15'),
(102, 'Simran Kaur', 'HR', 42000.50, '2022-02-10'),
(103, 'Arjun Singh', 'IT', 30000.00, '2024-01-20');

-- A. Number functions
-- 1. ABS()
SELECT ABS(-25) AS Absolute_Value;
-- 2. ROUND()
SELECT ROUND(123.456, 2) AS Rounded_Value;
-- 3. CEIL() and FLOOR()
SELECT CEIL(12.3) AS Ceiling_Value, FLOOR(12.3) AS Floor_Value;
-- 4. MOD()
SELECT MOD(10, 3) AS Remainder;
-- 5. Rounded employee salaries
SELECT Emp_Name, ROUND(Salary) AS Rounded_Salary FROM Employee;

-- B. Aggregate functions
-- 6. COUNT students
SELECT COUNT(*) AS Total_Students FROM Student;
-- 7. SUM salaries
SELECT SUM(Salary) AS Total_Salary FROM Employee;
-- 8. AVG salary
SELECT AVG(Salary) AS Average_Salary FROM Employee;
-- 9. MAX salary
SELECT MAX(Salary) AS Highest_Salary FROM Employee;
-- 10. MIN salary
SELECT MIN(Salary) AS Lowest_Salary FROM Employee;

-- C. Character functions
-- 11. UPPER()
SELECT UPPER(Name) AS Upper_Name FROM Student;
-- 12. LOWER()
SELECT LOWER(Name) AS Lower_Name FROM Student;
-- 13. LENGTH() returns bytes in MySQL
SELECT Name, LENGTH(Name) AS Name_Length FROM Student;
-- 14. CONCAT()
SELECT CONCAT(Name, ' - ', City) AS Student_Details FROM Student;
-- 15. SUBSTRING()
SELECT Name, SUBSTRING(Name, 1, 5) AS Name_Part FROM Student;

-- D. Conversion functions
-- 16. Number to string
SELECT CAST(12345 AS CHAR) AS Number_As_String;
-- 17. String to number
SELECT CAST('250' AS UNSIGNED) AS String_As_Number;
-- 18. Date in a different format
SELECT DATE_FORMAT('2025-03-08', '%d-%m-%Y') AS Formatted_Date;
-- 19. CAST()
SELECT CAST('99.50' AS DECIMAL(10,2)) AS Converted_Decimal;
-- 20. CONVERT()
SELECT CONVERT('2025-03-08', DATE) AS Converted_Date;

-- E. Date functions
-- 21. Current date
SELECT CURDATE() AS Current_Date;
-- 22. Extract year, month, day
SELECT YEAR(Joining_Date) AS Join_Year,
       MONTH(Joining_Date) AS Join_Month,
       DAY(Joining_Date) AS Join_Day
FROM Employee;
-- 23. Difference between dates
SELECT Emp_Name, DATEDIFF(CURDATE(), Joining_Date) AS Days_Employed
FROM Employee;
-- 24. Add days to a date
SELECT DATE_ADD('2025-01-01', INTERVAL 10 DAY) AS Date_After_10_Days;
-- 25. Joining date in required format
SELECT Emp_Name, DATE_FORMAT(Joining_Date, '%d/%m/%Y') AS Formatted_Joining_Date
FROM Employee;
